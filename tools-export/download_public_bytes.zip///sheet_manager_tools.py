from ibm_watsonx_orchestrate.agent_builder.tools import tool
from typing import Dict, Any, Optional, List
import re
import csv
import base64
from io import StringIO, BytesIO

try:
    import requests  # type: ignore
except Exception:
    requests = None  # type: ignore


@tool
def extract_drive_file_id(link: str) -> Dict[str, Any]:
    """Extract a Google Drive/Docs/Sheets file_id from a link."""
    if not link:
        return {"file_id": None}
    patterns = [
        re.compile(r"drive\.google\.com/file/d/([a-zA-Z0-9_-]+)"),
        re.compile(r"docs\.google\.com/(?:document|spreadsheets|presentation)/d/([a-zA-Z0-9_-]+)"),
        re.compile(r"drive\.google\.com/uc\?[^#]*\bid=([a-zA-Z0-9_-]+)"),
        re.compile(r"/d/([a-zA-Z0-9_-]+)"),
        re.compile(r"[?&]id=([a-zA-Z0-9_-]+)"),
    ]
    s = link.strip()
    for pat in patterns:
        m = pat.search(s)
        if m:
            return {"file_id": m.group(1)}
    return {"file_id": None}


@tool
def extract_drive_folder_id(link: str) -> Dict[str, Any]:
    """Extract a Google Drive folder_id from a folder link."""
    if not link:
        return {"folder_id": None}
    m = re.search(r"drive\.google\.com/drive/folders/([a-zA-Z0-9_-]+)", link)
    if m:
        return {"folder_id": m.group(1)}
    return {"folder_id": None}


@tool
def make_sheets_export_link(file_id: str, format: str = "csv", gid: int = 0) -> Dict[str, Any]:
    """Make a public export URL for a native Google Sheet."""
    fmt = (format or "csv").lower()
    if fmt not in ("csv", "xlsx"):
        fmt = "csv"
    url = f"https://docs.google.com/spreadsheets/d/{file_id}/export?format={fmt}&gid={gid}"
    return {"export_url": url}


@tool
def make_drive_download_link(file_id: str) -> Dict[str, Any]:
    """Make a public Drive download URL for any Drive file (including uploaded XLSX)."""
    url = f"https://drive.google.com/uc?export=download&id={file_id}"
    return {"drive_url": url}


@tool
def download_public_bytes(url: str, timeout_sec: int = 30) -> Dict[str, Any]:
    """Download bytes from a public URL."""
    if requests is None:
        return {"http_code": 0, "content_type": None, "file_bytes": b""}
    r = requests.get(url, timeout=timeout_sec)
    return {
        "http_code": r.status_code,
        "content_type": r.headers.get("Content-Type"),
        "file_bytes": r.content or b""
    }


@tool
def sniff_html_interstitial(file_bytes: bytes = b"", b: Optional[bytes] = None) -> Dict[str, Any]:
    """Detect HTML interstitial; accepts file_bytes or legacy b."""
    if (not file_bytes) and b:
        file_bytes = b
    head = (file_bytes or b"")[:300].lstrip()
    try:
        head_txt = head.decode("utf-8", errors="replace").lower()
    except Exception:
        head_txt = ""
    is_html = head_txt.startswith("<!doctype html") or "<html" in head_txt or "google drive" in head_txt
    return {"html": bool(is_html), "head": head_txt[:200]}


@tool
def sniff_table_file_type(file_bytes: bytes) -> Dict[str, Any]:
    """Infer file type: csv vs xlsx."""
    b0 = (file_bytes or b"")[:8]
    if b0.startswith(b"PK\x03\x04"):
        return {"file_type": "xlsx"}
    try:
        sample = file_bytes[:2000].decode("utf-8", errors="replace")
    except Exception:
        sample = ""
    if "," in sample or "\n" in sample:
        return {"file_type": "csv"}
    return {"file_type": "txt"}


@tool
def parse_csv_bytes(file_bytes: bytes, encoding: str = "utf-8", limit_rows: int = 5000) -> Dict[str, Any]:
    """Parse CSV bytes into headers/table/rows."""
    warnings: List[str] = []
    text = file_bytes.decode(encoding, errors="replace")
    reader = csv.reader(StringIO(text))
    table: List[List[str]] = []
    for i, row in enumerate(reader):
        if i >= limit_rows:
            warnings.append(f"Row limit {limit_rows} reached; truncated.")
            break
        table.append(row)

    headers = table[0] if table else []
    rows = []
    for r in table[1:]:
        obj = {}
        for j, h in enumerate(headers):
            obj[h] = r[j] if j < len(r) else ""
        rows.append(obj)

    return {
        "file_type": "csv",
        "headers": headers,
        "table": table,
        "rows": rows,
        "meta": {"row_count": len(rows), "warnings": warnings},
        "ok": True
    }


@tool
def parse_xlsx_bytes(file_bytes: bytes, limit_rows: int = 2000) -> Dict[str, Any]:
    """Parse XLSX bytes if openpyxl is available; else warn."""
    warnings: List[str] = []
    try:
        import openpyxl  # type: ignore
    except Exception as e:
        warnings.append(f"openpyxl unavailable: {e}")
        return {"file_type": "xlsx", "sheets": [], "meta": {"warnings": warnings}, "ok": True}

    wb = openpyxl.load_workbook(BytesIO(file_bytes), data_only=True)
    sheets_out = []
    for name in wb.sheetnames:
        ws = wb[name]
        sheet_rows = []
        for i, row in enumerate(ws.iter_rows(values_only=True)):
            if i >= limit_rows:
                warnings.append(f"{name}: row limit {limit_rows} reached; truncated.")
                break
            sheet_rows.append([cell for cell in row])
        sheets_out.append({"sheet": name, "rows": sheet_rows})

    return {"file_type": "xlsx", "sheets": sheets_out, "meta": {"warnings": warnings}, "ok": True}


@tool
def apply_sheet_patch(rows: List[Dict[str, Any]], patch_spec: Any) -> Dict[str, Any]:
    """Apply patch_spec over rows (append/update/delete)."""
    if rows is None:
        rows = []
    patches = patch_spec if isinstance(patch_spec, list) else [patch_spec]
    changes = 0
    updated = list(rows)

    def match_where(row: Dict[str, Any], where: Dict[str, Any]) -> bool:
        for k, v in (where or {}).items():
            if str(row.get(k, "")) != str(v):
                return False
        return True

    for p in patches:
        if not isinstance(p, dict):
            continue
        op = p.get("op")
        if op == "update":
            where = p.get("where", {})
            sets = p.get("set", {})
            for row in updated:
                if match_where(row, where):
                    for k, v in sets.items():
                        row[k] = v
                    changes += 1
        elif op == "append":
            row = p.get("row")
            if isinstance(row, dict):
                updated.append(row)
                changes += 1
        elif op == "delete":
            where = p.get("where", {})
            before = len(updated)
            updated = [r for r in updated if not match_where(r, where)]
            changes += (before - len(updated))

    return {"rows": updated, "meta": {"changes": changes}, "ok": True}


@tool
def build_csv_bytes(
    rows: List[Dict[str, Any]],
    headers: Optional[List[str]] = None,
    encoding: str = "utf-8",
    preview_rows: int = 20
) -> Dict[str, Any]:
    """Build CSV bytes from rows + headers. Returns base64 for orchestrate-safe passing."""
    if rows is None:
        rows = []
    if headers is None:
        headers = []
        seen = set()
        for r in rows:
            for k in r.keys():
                if k not in seen:
                    headers.append(k)
                    seen.add(k)

    out = StringIO()
    writer = csv.writer(out)
    writer.writerow(headers)
    for r in rows:
        writer.writerow([r.get(h, "") for h in headers])

    bts = out.getvalue().encode(encoding)
    b64 = base64.b64encode(bts).decode("ascii")

    preview_table: List[List[Any]] = [headers]
    for r in rows[:preview_rows]:
        preview_table.append([r.get(h, "") for h in headers])

    return {
        "file_bytes": bts,
        "file_bytes_b64": b64,
        "headers": headers,
        "row_count": len(rows),
        "preview_table": preview_table,
        "ok": True
    }


@tool
def decode_b64_to_bytes(file_bytes_b64: str) -> Dict[str, Any]:
    """Decode base64 string into raw bytes."""
    warnings: List[str] = []
    try:
        bts = base64.b64decode(file_bytes_b64.encode("ascii"))
        return {"file_bytes": bts, "ok": True, "meta": {"warnings": warnings}}
    except Exception as e:
        warnings.append(str(e))
        return {"file_bytes": b"", "ok": False, "meta": {"warnings": warnings}}

@tool
def parse_sheet_public(link_or_id: str, gid: int = 0, prefer: str = "csv", timeout_sec: int = 30) -> Dict[str, Any]:
    """One-shot public Sheet reader with Sheets-export then Drive-download fallback."""
    file_id = link_or_id
    if "http" in (link_or_id or ""):
        # tool-to-tool call -> use .fn
        file_id = extract_drive_file_id.fn(link_or_id).get("file_id")  # type: ignore

    if not file_id:
        return {"ok": False, "meta": {"warnings": ["Could not extract file_id."]}}

    # Try native sheets export
    export_url = make_sheets_export_link.fn(file_id, format=prefer, gid=gid).get("export_url")  # type: ignore
    dl = download_public_bytes.fn(export_url, timeout_sec=timeout_sec)  # type: ignore

    html_chk = sniff_html_interstitial.fn(dl.get("file_bytes", b""))  # type: ignore
    if (
        dl.get("http_code") != 200
        or "text/html" in str(dl.get("content_type", "")).lower()
        or html_chk.get("html")
    ):
        # Drive fallback
        drive_url = make_drive_download_link.fn(file_id).get("drive_url")  # type: ignore
        dl = download_public_bytes.fn(drive_url, timeout_sec=timeout_sec)  # type: ignore
        source = "drive_download"
    else:
        source = "sheets_export"

    ftype = sniff_table_file_type.fn(dl.get("file_bytes", b"")).get("file_type")  # type: ignore

    if ftype == "csv":
        parsed = parse_csv_bytes.fn(dl.get("file_bytes", b""))  # type: ignore
    elif ftype == "xlsx":
        parsed = parse_xlsx_bytes.fn(dl.get("file_bytes", b""))  # type: ignore
    else:
        parsed = {
            "file_type": ftype,
            "text": "",
            "meta": {"warnings": [f"Unsupported file type {ftype}"]},
            "ok": False
        }

    parsed["ok"] = parsed.get("ok", True)
    parsed["file_id"] = file_id
    parsed["source"] = source
    return parsed
